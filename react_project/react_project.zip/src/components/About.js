function About() {
    return (
      <div className="about container screen2">
          <p>This website suppose to help you with writing to each other secret messages. First, you need to create a note, and then take a hash of the note and send it to your friends.<br/>
          After they will search the full address with a hash in browser, and they will see your secret message. Have fun, and good luck!</p>
      </div>
    );
  }
  
  export default About;
  